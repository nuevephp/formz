<?php
/**
 * @package formz
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/fmzformsvalidation.class.php');
class fmzFormsValidation_mysql extends fmzFormsValidation {}