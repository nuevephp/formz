--------------------
Formz
--------------------
Version: 1.0.0
Author: Andrew Smith <a.smith@methodandclass.com>
--------------------

A Form Builder for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/silentworks/formz/issues
