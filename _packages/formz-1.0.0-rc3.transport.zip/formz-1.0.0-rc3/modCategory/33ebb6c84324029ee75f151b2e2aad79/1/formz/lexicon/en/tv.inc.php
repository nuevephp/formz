<?php
$_lang['formz'] = 'Formz';
$_lang['formz.output.properties.tpl'] = 'Form Template';
$_lang['formz.output.properties.fieldTpl'] = 'Form Field Template';
