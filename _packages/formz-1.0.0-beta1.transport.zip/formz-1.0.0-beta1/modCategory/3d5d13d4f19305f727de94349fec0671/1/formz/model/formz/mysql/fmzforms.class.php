<?php
/**
 * @package formz
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/fmzforms.class.php');
class fmzForms_mysql extends fmzForms {}