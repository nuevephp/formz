<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'fmzForms',
    1 => 'fmzFormsFields',
    2 => 'fmzFormsData',
    3 => 'fmzFormsDataFields',
  ),
  'xPDOObject' => 
  array (
    0 => 'fmzFormsValidation',
  ),
);