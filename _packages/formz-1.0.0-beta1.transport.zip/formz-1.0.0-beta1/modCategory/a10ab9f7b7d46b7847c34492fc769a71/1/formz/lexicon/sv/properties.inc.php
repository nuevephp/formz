<?php
/**
 * formz
 *
 * @package formz
 */
/**
 * Properties Swedish Lexicon Entries for formz
 *
 * @package formz
 * @subpackage lexicon
 */
$_lang['prop_formz.tpl'] = 'Standard Formz mall';
$_lang['prop_formz.id'] = 'Formulär ID';
$_lang['prop_formz.field_tpl'] = 'Standard Formz fält mall';
