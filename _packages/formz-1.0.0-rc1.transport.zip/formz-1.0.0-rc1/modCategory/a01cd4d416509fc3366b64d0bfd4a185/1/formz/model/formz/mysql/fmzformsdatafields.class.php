<?php
/**
 * @package formz
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/fmzformsdatafields.class.php');
class fmzFormsDataFields_mysql extends fmzFormsDataFields {}