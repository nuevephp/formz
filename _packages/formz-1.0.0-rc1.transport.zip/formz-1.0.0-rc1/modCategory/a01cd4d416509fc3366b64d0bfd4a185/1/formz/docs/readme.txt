--------------------
Formz
--------------------
Version: 1.0.0
Author: Andrew Smith <a.smith@silentworks.co.uk>
--------------------

A Form Builder for MODx Revolution.

Formz has two dependencies which need to be installed first. The dependencies are both
available through the MODX Package Management tool.

Dependencies:
	FormIt
	FormitFastPack

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/silentworks/formz/issues

---------------------
Contributors
---------------------
Romain (French Translation)
Joakim (Swedish Translation)
