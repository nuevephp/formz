<?php
/**
 * @package formz
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/fmzformsfields.class.php');
class fmzFormsFields_mysql extends fmzFormsFields {}