<?php
$_lang['formz'] = 'Formz';
$_lang['formz.output.properties.tpl'] = 'Template de formulaire';
$_lang['formz.output.properties.fieldTpl'] = 'Template de champ de formulaire';
