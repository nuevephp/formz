<?php
/**
 * @package formz
 */
class fmzFormsValidation extends xPDOObject {}