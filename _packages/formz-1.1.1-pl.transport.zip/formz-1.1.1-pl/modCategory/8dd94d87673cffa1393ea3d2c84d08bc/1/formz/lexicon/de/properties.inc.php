<?php
/**
 * formz
 *
 * @package formz
 */
/**
 * Properties English Lexicon Entries for formz
 *
 * @package formz
 * @subpackage lexicon
 */
$_lang['prop_formz.tpl'] = 'Formz-Standard-Template';
$_lang['prop_formz.id'] = 'Formular-ID';
$_lang['prop_formz.field_tpl'] = 'Formz-Standard-Formularfeld-Template';
