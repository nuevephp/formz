<?php
/**
 * formz
 *
 * @package formz
 */
/**
 * Properties English Lexicon Entries for formz
 *
 * @package formz
 * @subpackage lexicon
 */
$_lang['prop_formz.tpl'] = 'Default Formz template';
$_lang['prop_formz.id'] = 'Form ID';
$_lang['prop_formz.field_tpl'] = 'Default Formz field template';
