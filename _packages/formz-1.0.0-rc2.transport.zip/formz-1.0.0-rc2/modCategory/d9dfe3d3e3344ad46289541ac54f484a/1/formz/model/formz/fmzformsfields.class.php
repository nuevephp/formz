<?php
/**
 * @package formz
 */
class fmzFormsFields extends xPDOSimpleObject {}