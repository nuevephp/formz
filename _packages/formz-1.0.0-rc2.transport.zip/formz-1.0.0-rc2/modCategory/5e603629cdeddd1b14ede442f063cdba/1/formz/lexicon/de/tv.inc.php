<?php
$_lang['formz'] = 'Formz';
$_lang['formz.output.properties.tpl'] = 'Formular-Template';
$_lang['formz.output.properties.fieldTpl'] = 'Formularfeld-Template';
