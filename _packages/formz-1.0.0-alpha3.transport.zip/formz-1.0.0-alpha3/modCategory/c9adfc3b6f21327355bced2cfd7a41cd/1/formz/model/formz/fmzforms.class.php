<?php
/**
 * @package formz
 */
class fmzForms extends xPDOSimpleObject {}
