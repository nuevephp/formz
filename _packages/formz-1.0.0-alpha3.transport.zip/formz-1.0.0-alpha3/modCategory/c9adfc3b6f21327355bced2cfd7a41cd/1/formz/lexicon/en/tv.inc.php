<?php
$_lang['formz'] = 'Formz';
