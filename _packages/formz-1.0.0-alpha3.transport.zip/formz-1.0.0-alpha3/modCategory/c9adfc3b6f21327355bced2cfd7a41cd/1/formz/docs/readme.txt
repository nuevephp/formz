--------------------
Formz
--------------------
Version: 1.0.0
Author: Andrew Smith <a.smith@silentworks.co.uk>
--------------------

A Form Builder for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/silentworks/formz/issues
