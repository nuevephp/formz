<?php
$config['modx_base_path'] = '/www/modx22/';