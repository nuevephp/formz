<?php

$_lang['formitfastpack'] = 'FormitFastPack';
$_lang['formitfastpack_desc'] = '';

$_lang['setting_ffp.core_path'] = '';
$_lang['setting_ffp.inner_options_static'] = '';
