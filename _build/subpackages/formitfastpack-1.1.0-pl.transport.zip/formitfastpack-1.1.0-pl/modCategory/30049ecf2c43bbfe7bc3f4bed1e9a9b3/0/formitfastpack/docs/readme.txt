--------------------
Snippet: FormitFastPack
--------------------
Version: 1.0.0 alpha
Started: June 2011
Author: Oleg Pryadko (websitezen.com)
License: GNU GPLv3 (or later at your option)

# Help and Docs:
* Documentation: https://github.com/yoleg/FormitFastPack/wiki
* Issue Tracker: https://github.com/yoleg/FormitFastPack/issues
* Forum: http://forums.modx.com/index.php/topic,65244.0.html